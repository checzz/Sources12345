#include "J2716_Cfg.h"

const J2716_ConfigType  J2716_Config[]=
{
/*  CHANNEL PORT  PIN LENGHT  TICK(us)  PAUSE NOTIFICATION  */
{J2716_Ch0, NULL,  D0,     6,        3,  TRUE, NULL},
{J2716_Ch1, NULL,  D1,     6,        3,  TRUE, NULL},
};