/*
�Driver API (follow AUTOSAR naming convention) 10 %
  �Driver initialization
  �Data to be transmitted
  �Enable/Disable Notification

�Status Structures 10 %
  �Use Dynamic Memory Allocation with the following parameters
    �Channel
    �CRC1
    �CRC2
    ��
    �CRCn
    �Checksum

�Configuration Parameters 30 %
  �Tick period (3us � 90us, 3us resolution)
  �Enable optional pause pulse
  �Output pin
  �Message length (number of nibbles that have to be sent; 1 - 6)
  �Low driven pulse ticks ( > 4)
  �Support for [1 � n] SENT channels (use only one hardware timer)
  �Support for notification on each transmitted message

�File dependencies 10 %
  �Internal Driver Structure
  �Driver Dependencies to other Modules

�Interrupt Configuration 10 %
  �PIT interrupts XGATE (tick)
  �XGATE interrupts S12 (notification)

�Programmable with Omicron Bootloader 10 %
  �Use two buttons mechanism to invalidate application and generate MCU Reset

�SENT Protocol Driver Implemented on XGATE 20 % �Include a small application for changing the data to be transmitted (details in next slide)
  �Data consistency between S12 and XGATE
*/